﻿namespace PearReview.Areas.Identity.Data
{
    public enum UserRole
    {
        None = 0,
        Teacher = 1,
        Student = 2
    }
}
